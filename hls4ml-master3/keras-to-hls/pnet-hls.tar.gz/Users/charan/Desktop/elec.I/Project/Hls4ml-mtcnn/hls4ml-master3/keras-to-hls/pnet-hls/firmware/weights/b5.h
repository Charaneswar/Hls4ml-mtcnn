//Numpy array shape (2,)
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 2

bias_default_t b5[2] = {0.000000000000, 0.000000000000};
